package main;
//player와 enemy의 좌우 방향 확인하기 위한 열거형 클래스
public enum PlayerDirection {
	LEFT, RIGHT;
}
