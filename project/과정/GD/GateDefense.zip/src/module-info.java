/**
 * 
 */
/**
 * @author User
 *
 */
module GateDefense {
	requires java.desktop;
}