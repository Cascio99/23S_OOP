package tryToAttack;

public enum PlayerDirection {
	LEFT, RIGHT;
}
