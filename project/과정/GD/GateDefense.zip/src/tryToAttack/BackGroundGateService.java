package tryToAttack;

public class BackGroundGateService implements Runnable {
	private Gate gate;

	public BackGroundGateService(Gate gate) {

	}

	public void run() {
		// while(/*스테이지가 끝날 때 까지*/) {

	}
}
