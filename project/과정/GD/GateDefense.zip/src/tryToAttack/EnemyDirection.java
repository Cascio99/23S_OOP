package tryToAttack;

public enum EnemyDirection {
	LEFT, RIGHT, UP, DOWN;
}
