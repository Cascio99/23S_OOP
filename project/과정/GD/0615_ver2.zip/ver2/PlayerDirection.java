package ver2;

public enum PlayerDirection {
	LEFT, RIGHT;
}
