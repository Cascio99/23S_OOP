package ver2;

public enum EnemyDirection {
	LEFT, RIGHT, UP, DOWN;
}
